<?php
// teacher/register.php
